
## About SwopX

SwopX is a platform for buying, selling and swapping NFTs with a comprehensive set of analytic tools for pricing, authenticating and fraud protection.

Using AI and Machine Learning for millions of NFTs, we are able to give price forecasts for any NFT even with no prior price or sales history.

Users can buy, sell and swap NFTs on SwopX. Buyer pays a fee of 1% of the value for each purchase. For a swap transaction, both parties pay 1% of the value of the transaction. Sellers can mint and list NFTs with no fee.